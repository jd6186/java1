package com.lec.java.operator_review;

public class Operator_Review {
	public static void main(String[] args) {
		System.out.println("11월 20일 Java class 중  Operator에 applicable되는 Review를 Start합니다.");
		// 09은 수업에서 다루지 않아서 08에 작성한것
		
		// 문제 1. 디버깅을 하는 단축키 또는 아이콘 모양을 설명하라.
		
		// 문제 2. 브레이크 포인트를 잡는 방법에 대해 설명하라.
		
		// 문제 3. 브레이크 포인트를 다수 설정하였을 경우 다음 브레이크 포인트로 바로 보내주는 키의 이름과 위치 & 단축키를 말하라. 
		
		// 문제 4. 브레이크 포인트와 관계없이 한 행 씩 run을 진행하는 키의 이름과 단축키는 무엇인가?
		
		// 문제 5. 변수 하나를 만들어 "정동욱 천재"를 대입시키고 출력문을 만들고 디버깅 패이지에서 variable값을 "정동욱 300억 부자 천재 프로그래머"로 수정하여라.
		
		
		
		System.out.println("Review를 END합니다.");
		
		
	} // end main
}  // end class
