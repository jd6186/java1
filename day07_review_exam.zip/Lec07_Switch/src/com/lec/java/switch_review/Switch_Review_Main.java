package com.lec.java.switch_review;

public class Switch_Review_Main {
	public static void main(String[] args) {
		System.out.println("11월 20일 Java class 중  Switch에 applicable되는 Review를 Start합니다.");
		
		
		// 문제 1. 스위치 조건문이 if 조건문과 다른 점에 대해서 설명하라.
		
		// 문제 2. 스위치 조건문 내 조건이 총 4개가 되는 조건문을 만들어라. 안에 출력문구는 만들고 싶은데로
		

		// 문제 2. 스위치 조건문 내 주의사항에 대해 서술하라. 그리고 그 주의사항이 무엇 때문에 주의해야되는지도 설명하라.
		
		
		
		System.out.println("Review를 END합니다.");
		
		
	} // end main
} // end class	