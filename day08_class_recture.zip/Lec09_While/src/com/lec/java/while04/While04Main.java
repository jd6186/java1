package com.lec.java.while04;

public class While04Main {

	public static void main(String[] args) {
		System.out.println("while문 연습");
		
		
	} // end main()

} // end class While04Main









