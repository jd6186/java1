package practice.game369;

public class Game369 {
	public static void main(String[] args) {
		
	}
}
