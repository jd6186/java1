package com.lec.java.while02;

public class While02Main {

	public static void main(String[] args) {
		System.out.println("while 연습");
		
		
		System.out.println("▼    2단       ▼");
		// 구구단 2단 출력 : while 으로 만들기
		int i = 1;
		while (i <= 9) {
			System.out.println("2 x " + i + " = " + 2*i );
			i++;
		} //end while
//		구구단에서 단을 변수로 만들면 그 값만 바꿨을 때 쉽게 다른 단으로 바꿀 수 있다.
		int dan = 2; // 이런식으로
		
		
		
		


	} // end main()

} // end class While02Main









